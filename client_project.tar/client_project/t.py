import os

i = 0
while True:
    print(i)
    i += 1
    if i == 100:
        os._exit
