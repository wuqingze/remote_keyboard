java JavaClient >> log 2>&1 &
